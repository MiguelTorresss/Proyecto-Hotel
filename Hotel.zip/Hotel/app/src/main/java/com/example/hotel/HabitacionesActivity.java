package com.example.hotel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.view.View;
import android.widget.Button;

public class HabitacionesActivity extends AppCompatActivity implements View.OnClickListener {

    Button _btnFamiliar, _btnDoble;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_habitaciones);

        _btnFamiliar= findViewById(R.id.btnFamiliar);
        _btnDoble= findViewById(R.id.btnDoble);

        _btnFamiliar.setOnClickListener(this);
        _btnDoble.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnFamiliar:
                lanzarWhatsApp("3054001513");
                break;
            case R.id.btnDoble:
                lanzarWhatsApp("10148591312");
                break;
        }

    }

    private void lanzarWhatsApp(String telefono) {
        String toNumber = "57"+telefono;
        Intent sendIntent = new Intent("android.intent.action.MAIN");
        sendIntent.setComponent(new ComponentName("com.whatsapp","com.whatsapp.Conversation"));
        sendIntent.putExtra("jid", PhoneNumberUtils.stripSeparators(toNumber)+"@s.whatsapp.net");//phone number without "+" prefix
        startActivity(sendIntent);
    }
}