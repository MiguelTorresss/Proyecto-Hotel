package com.example.hotel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

public class FotoActivity extends AppCompatActivity {

    ImageView _foto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foto);
        _foto = findViewById(R.id.Foto);

        String foto = getIntent().getExtras().getString("foto");

        _foto.setImageResource(getResources().getIdentifier(foto,"drawable",getPackageName()));
    }
}