package com.example.hotel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class GaleriaActivity extends AppCompatActivity  implements View.OnClickListener {

    ImageView _f8, _f9, _f10, _f11, _f14, _f15;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_galeria);

        _f8 = findViewById(R.id.foto8);
        _f9 = findViewById(R.id.foto9);
        _f10 = findViewById(R.id.foto10);
        _f11 = findViewById(R.id.foto11);
        _f14 = findViewById(R.id.foto14);
        _f15 = findViewById(R.id.foto15);


        _f8.setOnClickListener(this);
        _f9.setOnClickListener(this);
        _f10.setOnClickListener(this);
        _f11.setOnClickListener(this);
        _f14.setOnClickListener(this);
        _f15.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        startActivity(new Intent(getApplicationContext(),FotoActivity.class).putExtra(v.getId()));
    }
}